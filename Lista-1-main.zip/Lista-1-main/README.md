Aqui está os exercícios que ja fiz em c.
